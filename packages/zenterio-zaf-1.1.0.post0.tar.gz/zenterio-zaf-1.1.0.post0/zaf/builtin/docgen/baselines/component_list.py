expected_rst_output = """
.. _list-components:

******************
List of Components
******************


.. toctree::
    :hidden:
    :glob:

    components/*


:ref:`component-comp1(call1)`:
    comp1 description

:ref:`component-comp2`:
    comp2 description
"""
