expected_rst_output = """
.. _list-extensions:

******************
List of Extensions
******************


.. toctree::
    :hidden:
    :glob:

    extensions/*


:ref:`extension-ext1`:
    module description.

:ref:`extension-ext2`:
    module description.

:ref:`extension-ext3`:
    module description.
"""
