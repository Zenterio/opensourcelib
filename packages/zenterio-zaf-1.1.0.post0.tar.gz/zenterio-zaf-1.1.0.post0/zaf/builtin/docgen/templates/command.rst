{% import 'macros.rst' as macros %}
.. _command-{{command.name|replace(' ', '_')}}:

{{ macros.format_command(command, 1, metadata.extension_names) }}
