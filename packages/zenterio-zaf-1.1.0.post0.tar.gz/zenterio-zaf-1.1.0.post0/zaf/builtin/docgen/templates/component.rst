{% import 'macros.rst' as macros %}
.. _component-{{component.name}}:

{{ macros.format_component(component, 1) }}
