************
Introduction
************

ZAF is an application framework with support for:

 * events
 * plugins/addons
 * metric collection
 * logging
 * configuration
 * command line argument parsing
